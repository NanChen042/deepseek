# DeepSeek AI 聊天助手集成指南

## 目录

1. [项目概述](#项目概述)
2. [环境准备](#环境准备)
3. [项目结构](#项目结构)
4. [组件详解](#组件详解)
5. [API 集成](#api-集成)
6. [常见问题](#常见问题)

## 项目概述

本项目是一个基于 Vue 3 + TypeScript + Element Plus 开发的 AI 聊天助手，集成了 DeepSeek 的 API 服务。主要特点：

- 🚀 基于 Vue 3 Composition API
- 💪 TypeScript 类型支持
- 🎨 Element Plus UI 组件库
- ✨ 打字机效果
- 📱 响应式设计
- �� 实时对话
- 🎯 简洁直观的界面
- 🔄 支持模型切换
- 🗑️ 对话清空确认
- 🎭 自定义用户头像

## 环境准备

### 1. 安装依赖
 
#### 创建项目

```bash
npm create vue@latest
```

#### 安装依赖

```bash
npm install element-plus @element-plus/icons-vue axios

```

### 2. 配置环境变量

创建 `.env.local` 文件：
  
```env
VITE_DEEPSEEK_API_KEY=your_api_key_here
```

## 项目结构

src/
├── components/
│ └── chat/
│ ├── ChatContainer.vue # 聊天容器组件
│ ├── ChatInput.vue # 输入组件
│ ├── MessageBubble.vue # 消息气泡组件
│ └── TypeWriter.vue # 打字机效果组件
├── services/
│ └── aiService.ts # API 服务
├── views/
│ ├── ChatView.vue # 聊天页面
│ └── HomeView.vue # 首页
└── App.vue # 根组件

## 组件详解

### 1. ChatContainer.vue

聊天容器组件是整个聊天界面的核心容器，负责：

- 消息列表的展示和管理
- 自动滚动控制
- 打字机效果的状态管理
- 模型切换功能
- 清空对话确认
- 响应式布局

关键功能：

```vue
<template>
  <div class="chat-container">
    <!-- 头部：标题、模型选择、清空按钮 -->
    <div class="chat-header">
      <div class="header-left">
        <h3>{{ title }}</h3>
        <el-select v-model="currentModel">
          <el-option v-for="..." />
        </el-select>
      </div>
      <el-button @click="showClearConfirm">清空全部对话</el-button>
    </div>
    
    <!-- 消息列表 -->
    <div class="chat-messages">
      <MessageBubble v-for="..." />
    </div>
    
    <!-- 输入区域 -->
    <ChatInput />
    
    <!-- 清空确认弹窗 -->
    <el-dialog v-model="showConfirmDialog">...</el-dialog>
  </div>
</template>
```

### 2. ChatInput.vue

输入组件特点：

- 自适应文本框高度
- 字数限制和显示
- Enter 快捷发送
- 优雅的加载状态
- 内联发送按钮
- 响应式布局适配

```vue
<template>
  <div class="chat-input">
    <div class="input-wrapper">
      <el-input
        v-model="message"
        type="textarea"
        :autosize="{ minRows: 1, maxRows: 4 }"
        :maxlength="2000"
        show-word-limit
      />
      <el-button class="send-button">
        <el-icon><Position /></el-icon>
        发送
      </el-button>
    </div>
  </div>
</template>
```

### 3. MessageBubble.vue

消息气泡组件特点：

- 区分用户和 AI 消息样式
- 自定义用户头像支持
- 内置打字机效果
- 消息时间显示
- 平滑动画效果
- 响应式布局

```vue
<template>
  <div :class="['message', isUser ? 'message-user' : 'message-ai']">
    <div class="message-content">
      <div class="avatar-wrapper">
        <el-avatar 
          :size="40" 
          :src="isUser ? userAvatar : undefined"
        >
          <el-icon v-if="!isUser"><Service /></el-icon>
        </el-avatar>
      </div>
      <div class="bubble-wrapper">
        <div class="bubble">
          <TypeWriter v-if="!isUser" :text="content" />
          <span v-else>{{ content }}</span>
        </div>
        <div class="time">{{ formatTime() }}</div>
      </div>
    </div>
  </div>
</template>
```

### 4. TypeWriter.vue

打字机效果组件特点：

- 可配置打字速度
- 完成事件通知
- 平滑的打字动画
- 支持长文本
- 自动滚动适配

## API 集成

### aiService.ts

增强的 API 服务：

```typescript
export enum ModelType {
  Chat = 'deepseek-chat',      // DeepSeek-V3
  Reasoner = 'deepseek-reasoner' // DeepSeek-R1
}

class AIChatService {
  public config: ChatRequestConfig
  
  constructor(config: Partial<ChatRequestConfig> = {}) {
    this.config = { ...DEFAULT_CONFIG, ...config }
  }

  // 支持模型切换
  updateConfig(newConfig: Partial<ChatRequestConfig>) {
    this.config = { ...this.config, ...newConfig }
  }

  // 通用对话
  async chat(messages: ChatCompletionRequestMessage[]) {
    // ... API 调用实现
  }

  // 推理增强
  async reason(prompt: string) {
    // ... 特殊处理逻辑
  }
}

export const aiService = new AIChatService()
```

## 常见问题

1. API 调用失败
- 检查 API Key 是否正确配置
- 确认网络连接状态
- 查看控制台错误信息
- 确认模型选择是否正确

2. 打字机效果问题
- 检查 isTyping 状态管理
- 确认消息类型判断
- 验证事件触发时机

3. 布局显示问题
- 检查响应式断点设置
- 确认容器高度计算
- 验证滚动条配置
- 检查 CSS 盒模型设置

4. 性能优化建议
- 合理使用 v-show 和 v-if
- 避免不必要的深度监听
- 优化滚动事件处理
- 使用虚拟滚动处理大量消息