<script setup lang="ts">
import { RouterLink, RouterView, useRoute } from "vue-router"
import { ref, watch } from 'vue'

const route = useRoute()
const activeIndex = ref(route.path)

// 监听路由变化，更新激活的菜单项
watch(() => route.path, (newPath) => {
  activeIndex.value = newPath
})
</script>

<template>
  <el-container class="app-container">
    <el-header class="app-header">
      <el-menu 
        mode="horizontal" 
        router 
        :ellipsis="false"
        :default-active="activeIndex"
      >
        <el-menu-item index="/">首页</el-menu-item>
        <el-menu-item index="/chat">Deepseek</el-menu-item>
      </el-menu>
    </el-header>

    <el-main class="app-main">
      <router-view></router-view>
    </el-main>
  </el-container>
</template>

<style scoped>
.app-container {
  min-height: 100vh;
  display: flex;
  flex-direction: column;
}

.app-header {
  padding: 0;
  height: 60px !important;
  flex-shrink: 0;
  box-shadow: 0 2px 4px rgba(0, 0, 0, 0.05);
  background: #fff;
  position: relative;
  z-index: 2;
}

.app-main {
  flex: 1;
  padding: 0;
  height: calc(100vh - 60px);
  position: relative;
  overflow-x: hidden;
}

/* 优化菜单样式 */
:deep(.el-menu) {
  border-bottom: none;
  height: 100%;
}

:deep(.el-menu-item) {
  font-size: 15px;
  transition: all 0.3s ease;
}

:deep(.el-menu-item.is-active) {
  font-weight: 600;
}
</style>
