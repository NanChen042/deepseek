<script setup lang="ts">
</script>

<template>
  <div class="home">
    <el-row justify="center" align="middle" class="welcome-section">
      <el-col :span="24" class="text-center">
        <h1>欢迎使用 Deepseek 语言模型</h1>
        <p>点击上方导航栏的 "Deepseek" 开始对话</p>
        <el-button type="primary" @click="$router.push('/chat')">
          开始对话
        </el-button>
      </el-col>
    </el-row>
  </div>
</template>

<style scoped>
.home {
  min-height: calc(100vh - 60px);
  overflow: hidden;
  background: #f5f7fa;
}

.welcome-section {
  padding-top: 120px;
}

.text-center {
  text-align: center;
}

h1 {
  font-size: 2.5em;
  color: #303133;
  margin-bottom: 20px;
}

p {
  font-size: 1.2em;
  color: #606266;
  margin-bottom: 30px;
}
</style>
