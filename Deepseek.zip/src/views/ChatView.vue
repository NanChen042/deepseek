<template>
  <div class="chat-view">
    <ChatContainer
      title="Deepseek 助手"
      :messages="messages"
      :loading="loading"
      @send="handleSend"
      @clear="clearChat"
      @modelChange="handleModelChange"
    />
  </div>
</template>

<script setup lang="ts">
import { ref } from 'vue'
import { ElMessage } from 'element-plus'
import ChatContainer from '@/components/chat/ChatContainer.vue'
import { aiService, ModelType } from '@/services/aiService'

interface Message {
  role: 'user' | 'assistant' | 'system'
  content: string
}

const messages = ref<Message[]>([
  {
    role: 'assistant',
    content: '你好！我是Deepseek，很高兴为您服务。'
  }
])

const loading = ref(false)

// 处理模型切换
const handleModelChange = (model: ModelType) => {
  aiService.updateConfig({
    model,
    system_message: model === ModelType.Reasoner 
      ? '你是一个专注于逻辑推理和问题分析的Deepseek。'
      : '你是一个友好的中文助手。'
  })
  ElMessage.success(`已切换至 ${model === ModelType.Reasoner ? '推理增强模型' : '通用对话模型'}`)
}

const handleSend = async (message: string) => {
  messages.value.push({
    role: 'user',
    content: message
  })

  loading.value = true

  try {
    // 根据当前模型选择使用不同的调用方式
    const aiResponse = aiService.config.model === ModelType.Reasoner
      ? await aiService.reason(message)
      : await aiService.chat(messages.value)
    
    messages.value.push({
      role: 'assistant',
      content: aiResponse
    })
  } catch (error) {
    console.error('Error:', error)
    ElMessage.error('发送消息失败，请重试')
  } finally {
    loading.value = false
  }
}

const clearChat = () => {
  messages.value = [{
    role: 'assistant',
    content: '你好！我是Deepseek，很高兴为您服务。'
  }]
}
</script>

<style scoped>
.chat-view {
  padding: 20px;
  background: #f5f7fa;
  height: calc(100vh - 60px);
  overflow: hidden;
  box-sizing: border-box;
}
</style> 