import axios from 'axios'
import type { ChatCompletionRequestMessage } from 'openai'

// API 配置
const API_CONFIG = {
  baseURL: 'https://api.deepseek.com',
  apiKey: import.meta.env.VITE_DEEPSEEK_API_KEY
}

// 模型类型
export enum ModelType {
  Chat = 'deepseek-chat',      // DeepSeek-V3
  Reasoner = 'deepseek-reasoner' // DeepSeek-R1
}

// 请求配置接口
interface ChatRequestConfig {
  model: ModelType
  temperature?: number
  max_tokens?: number
  stream?: boolean
  system_message?: string
}

// 默认配置
const DEFAULT_CONFIG: ChatRequestConfig = {
  model: ModelType.Chat,
  temperature: 0.7,
  max_tokens: 2000,
  stream: false,
  system_message: '你是一个友好的中文助手。'
}

/**
 * AI聊天服务类
 */
class AIChatService {
  public config: ChatRequestConfig
  
  constructor(config: Partial<ChatRequestConfig> = {}) {
    this.config = { ...DEFAULT_CONFIG, ...config }
  }

  /**
   * 发送聊天请求
   * @param messages 消息历史
   * @returns 
   */
  async chat(messages: ChatCompletionRequestMessage[]) {
    try {
      const response = await axios.post(
        `${API_CONFIG.baseURL}/v1/chat/completions`,
        {
          model: this.config.model,
          messages: [
            { role: 'system', content: this.config.system_message },
            ...messages
          ],
          temperature: this.config.temperature,
          max_tokens: this.config.max_tokens,
          stream: this.config.stream
        },
        {
          headers: {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${API_CONFIG.apiKey}`
          }
        }
      )
      return response.data.choices[0].message.content
    } catch (error: any) {
      console.error('Chat API error:', error)
      throw new Error(error.response?.data?.message || '聊天服务出错了')
    }
  }

  /**
   * 使用推理模型
   * @param prompt 提示词
   * @returns 
   */
  async reason(prompt: string) {
    const previousConfig = this.config.model
    try {
      this.config.model = ModelType.Reasoner
      return await this.chat([{ role: 'user', content: prompt }])
    } finally {
      this.config.model = previousConfig
    }
  }

  /**
   * 更新配置
   * @param newConfig 新配置
   */
  updateConfig(newConfig: Partial<ChatRequestConfig>) {
    this.config = { ...this.config, ...newConfig }
    console.log('Model updated:', this.config.model)
  }
}

// 导出服务实例
export const aiService = new AIChatService()

// 为了保持向后兼容
export const chatWithDeepSeek = (messages: ChatCompletionRequestMessage[]) => {
  return aiService.chat(messages)
} 